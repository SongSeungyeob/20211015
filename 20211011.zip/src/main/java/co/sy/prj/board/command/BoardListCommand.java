package co.sy.prj.board.command;

import java.util.ArrayList;
import java.util.List;

import co.sy.prj.board.service.BoardService;
import co.sy.prj.board.service.BoardVO;
import co.sy.prj.board.serviceImpl.BoardServiceImpl;

public class BoardListCommand implements Command {	// 게시글 목록보는 보는 것.
	private List<BoardVO> list = new ArrayList<BoardVO>();
	private BoardService dao = new BoardServiceImpl();
	
	@Override
	public void execute() {
		list = dao.boardSelectList();
		System.out.println("순번  :  작성자   :  작성일자  :          제목          : 조회수 ");
		for(BoardVO vo : list) {
			System.out.print(vo.getbId() + " : ");
			System.out.print(vo.getbWriter()+ " : ");
			System.out.print(vo.getbWriteDate()+ " : ");
			System.out.print(vo.getbTitle()+ " : ");
			System.out.println(vo.getbHit());
		}
	}
}
