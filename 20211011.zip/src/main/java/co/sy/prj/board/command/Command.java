package co.sy.prj.board.command;

public interface Command {
	public void execute();
}
