package co.sy.prj.board.command;

import co.sy.prj.board.service.BoardService;
import co.sy.prj.board.service.BoardVO;
import co.sy.prj.board.serviceImpl.BoardServiceImpl;

public class BoardSelect implements Command {

	@Override
	public void execute() {
		BoardService dao = new BoardServiceImpl();
		BoardVO board = new BoardVO();
		
		board.setbId(1);	// 1번글 가져오기.
		board = dao.boardSelect(board);
		System.out.println("번호 : " + board.getbId());
		System.out.println("작성자 : " + board.getbWriter());
		System.out.println("작성일자 : " + board.getbWriteDate());
		System.out.println("글 제목 : " + board.getbTitle());
		System.out.println("글 내용 : " + board.getbContents());
		System.out.println("조회수 : " + board.getbHit());
	}
}
