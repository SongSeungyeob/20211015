package co.sy.prj.comm;

public interface Command {
	public void Execute();
}
