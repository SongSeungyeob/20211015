package co.sy.prj;

import co.sy.prj.menu.Menu;

public class MainApp {
	public static void main(String[] args) {
		Menu menu = new Menu();
		menu.run();
	}
}
