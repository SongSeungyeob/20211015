package co.sy.lotto;

public class LottoMain {
	static int[] arr = new int[6];
	public static void main(String[] args) {
		Lotto lotto = new Lotto();
		lotto.run();
	}

}
